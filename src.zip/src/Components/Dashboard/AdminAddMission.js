import React, { useState, useEffect } from 'react';

export default function AdminAddMission() {
  const [seasons, setSeasons] = useState([]);
  const [form, setForm] = useState({
    season_id: "",
    title: "",
    description: "",
    image_url: "",
    question: "",
    hint: "",
    starter_code: "",
    difficulty: "",
    is_locked: false
  });

  useEffect(() => {
    // Adjust the URL if your backend is running on a different port or host
    fetch('http://localhost:5000/api/seasons')
      .then(res => res.json())
      .then(setSeasons);
  }, []);

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setForm(f => ({
      ...f,
      [name]: type === 'checkbox' ? checked : value
    }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    fetch("http://localhost:5000/api/missions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          alert("Mission added!");
          setForm({
            season_id: "",
            title: "",
            description: "",
            image_url: "",
            question: "",
            hint: "",
            starter_code: "",
            difficulty: "",
            is_locked: false
          });
        } else {
          alert("Failed to add mission");
        }
      });
  }

  return (
    <div>
      <h2>Add New Mission</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Season:
          <select name="season_id" value={form.season_id} onChange={handleChange} required>
            <option value="">Select a season</option>
            {seasons.map(s => (
              <option key={s.id} value={s.id}>{s.title}</option>
            ))}
          </select>
        </label>
        <br />
        <label>
          Mission Title:
          <input name="title" value={form.title} onChange={handleChange} required />
        </label>
        <br />
        <label>
          Description:
          <textarea name="description" value={form.description} onChange={handleChange} />
        </label>
        <br />
        <label>
          Image URL:
          <input name="image_url" value={form.image_url} onChange={handleChange} />
        </label>
        <br />
        <label>
          Question:
          <textarea name="question" value={form.question} onChange={handleChange} />
        </label>
        <br />
        <label>
          Hint:
          <input name="hint" value={form.hint} onChange={handleChange} />
        </label>
        <br />
        <label>
          Starter Code:
          <input name="starter_code" value={form.starter_code} onChange={handleChange} />
        </label>
        <br />
        <label>
          Difficulty:
          <input name="difficulty" value={form.difficulty} onChange={handleChange} />
        </label>
        <br />
        <label>
          Locked?
          <input type="checkbox" name="is_locked" checked={form.is_locked} onChange={handleChange} />
        </label>
        <br />
        <button type="submit">Add Mission</button>
      </form>
    </div>
  );
}
